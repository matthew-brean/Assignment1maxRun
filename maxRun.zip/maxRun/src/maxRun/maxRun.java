/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2016-09-18
* Created for: ICS4U
* Assignment: #1b
* This program calculates the max run of a string given by user
*******************************************************************************/

package maxRun;
import java.util.Scanner;

public class maxRun {

    public static void main(String[] args) {
    
       Scanner ASSIGNMENTONE = new Scanner(System.in);
       System.out.println("Enter a string.");
       String stringToFindMaxRun = ASSIGNMENTONE.nextLine();
       
       System.out.println("The maximum run is: " + maxRun(stringToFindMaxRun));
        
    }

    public static int maxRun(String str) {
        if (str.length() == 0) { return 0; }

        int maxCheck = 0,
            maxRun = 1,
            currentRun = 1;

        if (str.length() == 1) { return maxRun; }


        //i is a counter and is used to determine at which character 
        //in the string the program is searching
        
        for (int i = 1; i < str.length(); i++) {
            if (str.charAt(i) == str.charAt(i - 1)) {
                currentRun++;
                if (currentRun > maxRun) {maxRun = currentRun;}
            }
            else { currentRun = 1; }
        }
        return maxRun;
    }
}